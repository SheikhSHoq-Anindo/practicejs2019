var keyPressCount = 0;
var input;
var code;
var lastRawInput;

function changeElement(keyName) {
    keyPressCount++ ;
    if(keyPressCount<5) {
        document.getElementById(keyName).src="asset/img/key_Red.png";
        document.getElementById("demo1").innerHTML=keyName;
        keystrokecheck(keyName);
               
        if(Boolean(lastRawInput)){code =lastRawInput + input  ;}
        else{code = input;}
        document.getElementById("dsp02").innerHTML=code;
        document.getElementById("demo2").innerHTML=code;
        lastRawInput = code;
    }

    if (keyPressCount == 4){
        setInterval(checkCode,1000);
        keystrokecheck(keyName);
    }
    
    document.getElementById("demo3").innerHTML=keyPressCount;
}

function checkCode() {
    if (code != "0000"){
        document.getElementById("dsp01").style.backgroundImage="url(asset/gif/terminal_error.gif)";
        document.getElementById("dsp02").innerHTML= "Err:Input invalid! Please [RESET]";
        
        // Get a NodeList of all .demo elements
        const keys = document.querySelectorAll('.key_Neut');
        // Change the text of multiple elements with a loop
        keys.forEach(element => {
        element.src = 'asset/img/key_Red.png';
        });
    }
    else{
        document.getElementById("dsp01").style.backgroundImage="url(asset/gif/terminal_unlocked.gif)";
        document.getElementById("dsp02").innerHTML= "Link input successful";
        const keys = document.querySelectorAll('.key_Neut');
        keys.forEach (e =>{
            e.src = 'asset/img/key_Green.png';
        });
    }
            
}

function keystrokecheck (key2check) {
    document.getElementById("demo1").innerHTML=key2check;
        switch (key2check) {
        case "k1" : input = "1"; break;
        case "k2" : input = "2"; break;
        case "k3" : input = "3"; break;
        case "k4" : input = "4"; break;
        case "k5" : input = "5"; break;
        case "k6" : input = "6"; break;
        case "k7" : input = "7"; break;
        case "k8" : input = "8"; break;
        case "k9" : input = "9"; break;
        case "k0" : input = "0"; break;
        case "kC" : clear(); break;
        case "kR" : reset(); break;
        default: input ="nothing"; break;
        }
}

function clear() {
    document.getElementById("demo2").innerHTML="clear called";
    temp = code.slice(0,keyPressCount-2);
    code = temp;
   
}

function reset() {
    document.getElementById("demo2").innerHTML="reset called";
    keyPressCount=0;
    document.getElementById("demo3").innerHTML=keyPressCount;
    const keys = document.querySelectorAll(".key_Neut");
    keys.forEach (e =>{
        e.src = 'asset/img/key_Neut.png';   
    });
    document.getElementsById("dsp01").style.backgroundImage="url(asset/gif/terminal_idle.gif)";
}



